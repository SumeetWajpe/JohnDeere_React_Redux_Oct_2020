// const INCREMENT_LIKES = 'INCREMENT_LIKES'
export function IncrementLikes(){
    return {type:'INCREMENT_LIKES'};
}
export function AddProduct(){
    return {type:'ADD_PRODUCT'};
}
export function DeleteProduct(){
    return {type:'DELETE_PRODUCT'};
}
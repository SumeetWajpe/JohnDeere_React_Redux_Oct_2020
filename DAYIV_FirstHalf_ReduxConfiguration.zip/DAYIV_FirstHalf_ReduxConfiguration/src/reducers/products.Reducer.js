export function products(defStore = [], action) {
  switch (action.type) {
    case "INCREMENT_LIKES":
      console.log("Within products reducer ! -> INCREMENT_LIKES");
      console.log(action);
      return defStore; //return new store (products) !
    case "ADD_PRODUCT":
      console.log("Within products reducer -> ADD_PRODUCT !");
      console.log(action);
      return defStore; //return new store (products) !
    case "DELETE_PRODUCT":
      console.log("Within products reducer -> DELETE_PRODUCT !");
      console.log(action);
      return defStore; //return new store (products) !
    default:    
      return defStore; //return new store (products) !
  }
}

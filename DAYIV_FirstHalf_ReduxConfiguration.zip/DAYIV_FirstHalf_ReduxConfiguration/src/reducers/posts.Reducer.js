export function posts(defStore = [], action) {
  switch (action.type) {
    case "ADD_POST":
      console.log("Within posts reducer->ADD_POST !");
      console.log(action);
      return defStore; //return new store (posts) !
    default:     
      return defStore; //return new store (posts) !
  }
}

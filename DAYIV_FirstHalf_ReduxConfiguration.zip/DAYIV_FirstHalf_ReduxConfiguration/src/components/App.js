import './App.css';
import ListOfProducts from './listofproducts.component';

function App(props) {
 
  return (
    <div>     
      <ListOfProducts allProducts={props.allProducts} />
    </div>
  );
}

export default App;

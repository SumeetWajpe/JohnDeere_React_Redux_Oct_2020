import React from 'react';
import {Counter} from './CounterToTest';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import { shallow } from 'enzyme';


Enzyme.configure({ adapter: new Adapter() });

xdescribe('Counter Test Suite',()=>{
    it('should start with count 0',()=>{
        // create an Counter instance
        // check if the count == 0

        const wrapper = shallow(<Counter />); // enzyme renderer to create the instance !
        var initialCount = wrapper.state().count;
        expect(initialCount).toBe(0);
    });
    
    it('increments count on click of button',()=>{
        const wrapper = shallow(<Counter />);// has the html(DOM)
        var btn = wrapper.find('button');
        btn.simulate('click');
        var pText = wrapper.find('p').text();
        expect(pText).toEqual('Count : 1');
    })
})
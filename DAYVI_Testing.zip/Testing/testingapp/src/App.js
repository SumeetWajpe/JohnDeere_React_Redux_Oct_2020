import logo from './logo.svg';
import './App.css';
import { Counter } from './CounterToTest';

function App() {
  return (
    <div className="App">
     <Counter></Counter>
    </div>
  );
}

export default App;

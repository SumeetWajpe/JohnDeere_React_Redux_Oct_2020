export default function Addition(x,y){
    return x + y;
}

export function Multiplication(x,y){
    return x * y;
}

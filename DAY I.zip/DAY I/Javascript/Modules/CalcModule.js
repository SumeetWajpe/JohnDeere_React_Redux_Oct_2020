import Add,{Multiplication} from './MathModule.js';
console.log(Add(20,30));
console.log(Multiplication(20,30));


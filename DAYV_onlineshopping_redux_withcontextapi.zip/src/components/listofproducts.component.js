import React from "react";
import { PropsFromReduxContext } from "./App";
import Product from "./product.component";

class ListOfProducts extends React.Component {
  render() {
    
    return (
      <PropsFromReduxContext.Consumer>
        {(context) => (
          <React.Fragment>
            <div className="jumbotron">
              <h1>Online Shopping</h1>
            </div>
            <div className="row">{
              context.allProducts.map((p) => (
                <Product productdetails={p} key={p.id}  />
              ))
            }</div>
          </React.Fragment>
        )}
      </PropsFromReduxContext.Consumer>
    );
    // babel JS converts JSX to React API !
  }
}

export default ListOfProducts;

// const INCREMENT_LIKES = 'INCREMENT_LIKES'
export function IncrementLikes(pid){
    return {type:'INCREMENT_LIKES',pid};
}
export function AddProduct(){
    return {type:'ADD_PRODUCT'};
}
export function DeleteProduct(pid){
    return {type:'DELETE_PRODUCT',pid};
}
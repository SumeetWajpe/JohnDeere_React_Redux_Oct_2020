let pid;
let theIndex;
export function products(defStore=[], action) {
  switch (action.type) {
    case "INCREMENT_LIKES":
      pid = action.pid;
      theIndex = defStore.findIndex(p=>p.id === pid);

      return [
          ...defStore.slice(0,theIndex),
          {...defStore[theIndex],likes:defStore[theIndex].likes+1},
          ...defStore.slice(theIndex+1)
      ];
      
    case "ADD_PRODUCT":
      console.log("Within products reducer -> ADD_PRODUCT !");
      console.log(action);
      return defStore; //return new store (products) !
    case "DELETE_PRODUCT":
      pid = action.pid;
      theIndex = defStore.findIndex(p=>p.id === pid);

      return [
          ...defStore.slice(0,theIndex),          
          ...defStore.slice(theIndex+1)
      ];// can use filter as well
    default:      
      return defStore; //return new store (products) !
  }
}

import {combineReducers} from 'redux';
import {products} from './products.Reducer';
import { posts } from "./posts.Reducer";

var rootReducer = combineReducers({posts,products});
export default rootReducer;
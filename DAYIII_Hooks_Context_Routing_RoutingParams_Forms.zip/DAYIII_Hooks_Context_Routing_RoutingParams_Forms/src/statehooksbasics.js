import React, { useState } from 'react'

export const Counter = () => {
    const [currCount,setcurrCount] = useState(10);// destructuring
    return(
        <div>
            <p>Current Count is : {currCount}</p>
            <button onClick={()=>setcurrCount(currCount+1)}>
                +
            </button>
        </div>
    )
}

export default Counter
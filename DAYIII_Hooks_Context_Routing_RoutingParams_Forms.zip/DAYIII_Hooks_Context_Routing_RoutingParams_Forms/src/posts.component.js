import React from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

export default class Posts extends React.Component{
    constructor(){
        super();
        this.state = {posts:[]};
    }
    componentDidMount(){
        // make an AJAX request !
        let aPromise = axios.get('https://jsonplaceholder.typicode.com/posts')
        aPromise.then(
        response=>this.setState({posts:response.data}),
        err=>console.log(err));
    }
    render(){
        let allPostsToBeCreated = this.state.posts.map(
            p=><li key={p.id}> <Link to={"/postdetails/" + p.id}> {p.title} </Link>  </li>
            );
        return <React.Fragment>
                    <div className="jumbotron">
                        <h1> All Posts !</h1>
                    </div>                    
                    <ul>
                        {allPostsToBeCreated}
                    </ul>
                </React.Fragment> 
    }
}   
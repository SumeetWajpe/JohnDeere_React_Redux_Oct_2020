import React from "react";
import logo from "./logo.svg";
import "./App.css";
import ListOfProducts from "./listofproducts.component";
import Posts from "./posts.component";
import Message from "./functional.component";
import Counter from "./statehooksbasics";
import PostsUsingEffectHook from "./useeffectbasics";
import ShoppingCart from "./contextapi";
import { BrowserRouter, Route, Switch, Link, Redirect } from "react-router-dom";
import PostDetails from "./postdetails";
import { AddNewProduct } from "./addnewproduct.component";

class App extends React.Component {
  render() {
    return (
      <BrowserRouter>
        <nav className="navbar navbar-inverse">
          <div className="container-fluid">
            <div className="navbar-header">
              <Link className="navbar-brand" to="/">
                Online Shopping
              </Link>
            </div>
            <ul className="nav navbar-nav">
              <li>               
                <Link to="/">Home</Link>
              </li>
              <li>               
                <Link to="/newproduct">New Product</Link>
              </li>
              <li>
                <Link to="/posts">Posts</Link>
              </li>
              <li>
                <Link to="/postshooks">Posts(Hooks)</Link>
              </li>
            </ul>
          </div>
        </nav> 
        <Switch>
          <Route path="/" exact component={ListOfProducts}></Route>
          <Route path="/newproduct" exact component={AddNewProduct}></Route>

          <Route path="/posts" exact component={Posts}></Route>        
          <Route path="/postdetails/:id" exact component={PostDetails}></Route>
          <Route path="/postshooks" exact component={PostsUsingEffectHook}></Route>
          <Route path="/message" exact render={()=><Message msg="Hello From Router !" />}></Route> 
          <Route path="**" render={()=> <Redirect to="/" /> }></Route>
        </Switch>
      </BrowserRouter>
    );
  }
}

export default App;

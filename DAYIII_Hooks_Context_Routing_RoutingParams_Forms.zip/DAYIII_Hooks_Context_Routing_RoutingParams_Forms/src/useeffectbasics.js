import React, { useEffect, useState } from 'react'
import axios from 'axios';

export const PostsUsingEffectHook = () => {
    const [posts,setposts] = useState([]);
    useEffect(()=>{
        let aPromise = axios.get('https://jsonplaceholder.typicode.com/posts')
        aPromise.then(
        response=>setposts(response.data),
        err=>console.log(err));
    },[]);

    return(
        <div>
            <div className="jumbotron">
                        <h1> All Posts (EffectHook) !</h1>                        
                    </div> 
                    <ul>
                              {posts.map(p=><li key={p.id}>{p.title}</li>)}  
                        </ul>
        </div>
    )
}

export default PostsUsingEffectHook;
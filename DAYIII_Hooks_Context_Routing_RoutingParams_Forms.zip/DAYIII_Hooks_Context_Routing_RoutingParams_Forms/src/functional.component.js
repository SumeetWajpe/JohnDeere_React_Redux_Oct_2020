
import React from 'react';


// Light weighted
// Doesn't have Life Cycle methods ! - Effect Hook (16.8+)
// Doesn't have state ! - State Hook (16.8+)

export default function Message(props){
    return <h1> {props.msg} </h1>
}
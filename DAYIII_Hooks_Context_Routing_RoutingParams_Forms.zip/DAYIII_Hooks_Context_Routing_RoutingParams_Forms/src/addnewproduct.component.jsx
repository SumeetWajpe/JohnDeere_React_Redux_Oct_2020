import React, { useState } from 'react'


export const AddNewProduct = (props) => {
    const [newProduct,setnewProduct] = useState({
        id:0,
        title:"",
        quantity:0,
        price:0,
        rating:0,
        likes:0,
        imageUrl:""
    });
    function OnFormSubmit(event){         
        event.preventDefault();
        console.log(newProduct);
    }  
    
    return(
        <div>
           <div className="jumbotron">
                <h1>New Product</h1>
           </div>
           
           <form onSubmit={OnFormSubmit}>

            Id : <input type="text" value={newProduct.id} onChange={(e)=> setnewProduct({...newProduct, id: +(e.target.value)})} /><br/>
            Title : <input type="text" value={newProduct.title} onChange={(e)=> setnewProduct({...newProduct, title: e.target.value})} /><br/>
            Quantity : <input type="text" value={newProduct.quantity} onChange={(e)=> setnewProduct({...newProduct, quantity: e.target.value})} /><br/>
            Price : <input type="text" value={newProduct.price} onChange={(e)=> setnewProduct({...newProduct, price: +(e.target.value)})} /><br/>
            Rating : <input type="text" value={newProduct.rating} onChange={(e)=> setnewProduct({...newProduct, rating: +(e.target.value)})} /><br/>
            Likes : <input type="text" value={newProduct.likes} onChange={(e)=> setnewProduct({...newProduct, likes: +(e.target.value)})} /><br/>
            ImageUrl : <input type="text" value={newProduct.imageUrl} onChange={(e)=> setnewProduct({...newProduct, imageUrl: e.target.value})} /><br/>

            <input type="submit" value="Submit" />
           </form>
        </div>
    )
}

export default AddNewProduct;
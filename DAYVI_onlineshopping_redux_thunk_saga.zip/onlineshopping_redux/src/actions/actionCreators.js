// const INCREMENT_LIKES = 'INCREMENT_LIKES'
import axios from 'axios';
export function IncrementLikes(pid){
    return {type:'INCREMENT_LIKES',pid};
}

export function IncrementLikesDelayed(pid){
    return {type:'INCREMENT_LIKES_DELAYED',pid};
}
export function AddProduct(){
    return {type:'ADD_PRODUCT'};
}
export function DeleteProduct(pid){
    return {type:'DELETE_PRODUCT',pid};
}

export function FetchPostsAsync(){
   return {type:'FETCH_POSTS_ASYNC'}
}

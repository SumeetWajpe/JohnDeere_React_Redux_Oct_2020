import axios from 'axios';
import {call, delay, put, retry , takeEvery, takeLatest,debounce, race} from 'redux-saga/effects';

export function* fetchPostsAsync(){
    // get the response from ajax request !
    delay(5000);
   let response = yield call(axios.get,"https://jsonplaceholder.typicode.com/posts");// make axios.get('jsonplace..')
   yield put({type:'FETCH_POSTS',response:response.data});
}
export function* incrementLikesDelayed({pid}){
    // get the response from ajax request !
    console.log('Delaying !')
    //yield delay(5000);
    yield put({type:'INCREMENT_LIKES',pid});
}

function CallPosts(){
  return  axios.get("https://jsonplaceholder.typicode.com/postss");
}

export function* retrySaga(){
    try{
           let response = yield retry(3,5000,CallPosts);
           yield put({type:'FETCH_POSTS',response:response.data});
    }
    catch(error){
        yield put({type:'REQUEST_FAIL'})
    }
}

export function* fetchPostsWithTimeout(){
   var {posts,timeout} =  yield race({
        posts: call(axios.get,"http://jsonplaceholder.typicode.com/posts"),
        timeout: delay(100)
    });

    if(posts)
        yield put({type:'FETCH_POSTS',response:posts.data});
    else
        yield console.log('TIMEOUT_ERROR');
}

export function* watchFetchPosts(){
    // yield takeEvery('FETCH_POSTS_ASYNC',fetchPostsAsync);
    // yield takeLatest('INCREMENT_LIKES_DELAYED',incrementLikesDelayed);
    //yield debounce(2000,'INCREMENT_LIKES_DELAYED',incrementLikesDelayed);
    //yield retrySaga('FETCH_POSTS_ASYNC',retrySaga);
     yield takeEvery('FETCH_POSTS_ASYNC',fetchPostsWithTimeout);
}
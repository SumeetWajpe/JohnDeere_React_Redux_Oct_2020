import React from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

export default class Posts extends React.Component{ 
    componentDidMount(){
        this.props.FetchPostsAsync(); // dispatch an action
        // this.props.FetchPostsAsync(); // dispatch an action
        // this.props.FetchPostsAsync(); // dispatch an action
        // this.props.FetchPostsAsync(); // dispatch an action
        // this.props.FetchPostsAsync(); // dispatch an action

    }
    render(){
        let allPostsToBeCreated = this.props.allPosts.map(
            p=><li key={p.id}> <Link to={"/postdetails/" + p.id}> {p.title} </Link>  </li>
            );
        return <React.Fragment>
                    <div className="jumbotron">
                        <h1> All Posts !</h1>
                    </div>                    
                    <ul>
                        {allPostsToBeCreated}
                    </ul>
                </React.Fragment> 
    }
}   
import React from "react";
import { PropsFromReduxContext } from "./App";
import "./product.component.css";

export default class Product extends React.Component {
   render() {
    return (
      <PropsFromReduxContext.Consumer>
        {
          context =>(
            <div className="col-sm-5 col-md-4">
            <div className="productStyle">       
            <h1>{this.props.productdetails.title}</h1>
            <img src={this.props.productdetails.ImageUrl} height="100px" width="100px"/>
            <br />
            <strong>Price : </strong> {this.props.productdetails.price} <br />
            <strong>Quantity : </strong> {this.props.productdetails.quantity} <br />
            <strong>Rating : </strong> {this.props.productdetails.rating} <br />
            <button className="btn btn-primary"
            onClick={()=>context.IncrementLikes(this.props.productdetails.id)}>
              <span className="glyphicon glyphicon-thumbs-up"></span>
              {this.props.productdetails.likes}
            </button>{" "}
            <button className="btn btn-danger" onClick={()=>context.DeleteProduct(this.props.productdetails.id)}>
              <span className="glyphicon glyphicon-trash"></span>       
            </button>
            </div>
          </div>
       
          )
        }
      </PropsFromReduxContext.Consumer>
      );
  }
}

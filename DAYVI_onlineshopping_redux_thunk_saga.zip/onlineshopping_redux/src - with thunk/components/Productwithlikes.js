import React from 'react'

export const ProductWithLikes = (props) => {
    
let allProductsWithLikes = props.allProducts.map(p=><li key={p.id}>{p.title} - {p.likes}</li>)
    return(
        <div>
           <ul>
               {allProductsWithLikes}
           </ul> 
        </div>
    )
}

export default ProductWithLikes
const customLoggerMiddleware = store =>{
    return next =>{
        return action =>{
            console.group(action.type);
            // console.log(new Date().getMilliseconds());
            console.log('Previous Store data ->',store.getState());
            console.log('Action Dispatched ->',action);
            let result = next(action); // dispatch
            console.log('Changed Store data ->',store.getState())
            console.groupEnd(action.type);
            return result;
        }
    }
}

export default customLoggerMiddleware;
export function posts(defStore = [], action) {
  switch (action.type) {
    case "ADD_POST":
      console.log("Within posts reducer->ADD_POST !");
      console.log(action);
      return defStore; //return new store (posts) !
    case 'FETCH_POSTS':
      return action.response;
    default:      
      return defStore; //return new store (posts) !
  }
}

// const INCREMENT_LIKES = 'INCREMENT_LIKES'
import axios from 'axios';
export function IncrementLikes(pid){
    return {type:'INCREMENT_LIKES',pid};
}
export function AddProduct(){
    return {type:'ADD_PRODUCT'};
}
export function DeleteProduct(pid){
    return {type:'DELETE_PRODUCT',pid};
}

export function FetchPosts(response){
   return {type:'FETCH_POSTS',response}
}
export function FetchPostsAsync(){
    return dispatch =>
    axios.get('https://jsonplaceholder.typicode.com/posts')
    .then(response=>{
            console.log();
            return dispatch(FetchPosts(response.data));
        },
        err => console.log(err)
    )    
}